/**
 * @typedef GeoLocation {object}
 * @property latitude {string}
 * @property longitude {string}
 * @property alias {string}
 */

/**
 * @typedef SetupOptions {object}
 * @property map {object}
 * @property map.mapId {string}
 * @property map.zoomLevel {number}
 * @property ikeaStoreName {string}
 * @property stopName {string}
 * @property vehicle {object}
 * @property vehicle.deviceId {string}
 */

/**
 * @typedef SetupResult {object}
 * @property mapProps {object}
 * @property mapProps.map {object}
 * @property mapProps.busMarker {object}
 * @property mapData {object}
 * @property locations.ikeaLocation {GeoLocation}
 * @property locations.stopLocation {GeoLocation}
 * @property dataUrl {string} - url for fetching vehicle data
 * @property infoWindow {object}
 * @property setupOptions {SetupOptions}
 */

/**
 * @typedef UserMessage {object}
 * @property message {string}
 * @property destination {string}
 * @property arrivalTime {string}
 */

/**
 * @typedef MapData {object}
 * @property [lastGeofencingEvent] {object}
 * @property lastGeofencingEvent.type {string}
 * @property lastGeofencingEvent.location {string}
 * @property [lastGeofencingEvent.geoLocation] {GeoLocation}
 * @property lastLocation.timestamp {moment}
 * @property lastLocation.geoLocation {object}
 * @property lastLocation.geoLocation.latitude {string}
 * @property lastLocation.geoLocation.longitude {string}
 * @property [navigation] {NavigationResult}
 * @property userMessage {UserMessage}
 */

// =======================

/**
 * entry point
 * @param options {SetupResult}
 * @param timeout {number}
 */
function refreshMapDataRunner(options, timeout) {
  _refreshMapData(options).catch(console.error);
  setInterval(() => _refreshMapData(options), timeout);
}

/**
 *
 * @param options {SetupOptions}
 * @returns {SetupResult}
 */
function setup(options) {
  const ikeaLocation = getGeoLocationByName(options.ikeaStoreName);
  const stopLocation = getGeoLocationByName(options.stopName);

  const startLocation = ikeaLocation;
  const lat = startLocation.latitude;
  const lng = startLocation.longitude;

  const map = new google.maps.Map(document.getElementById(options.map.mapId), {
    center: { lat, lng },
    zoom: options.map.zoomLevel,
    disableDefaultUI: false
  });

  const trafficLayer = new google.maps.TrafficLayer();
  trafficLayer.setMap(map);

  const busMarker = new google.maps.Marker({
    // position: { lat, lng },
    icon: {
      url: window.BUS_IMAGE_URL,
      size: new google.maps.Size(30, 30),
      scaledSize: new google.maps.Size(30, 30),
      origin: new google.maps.Point(0, 0)
    },
    map: map,
    optimized: false
  });

  const infoWindow = new google.maps.InfoWindow({
    content: "<b> Ikea Shuttle </b>"
  });
  infoWindow.open(map, busMarker);

  return {
    mapProps: { map, busMarker },
    mapData: { ikeaLocation, stopLocation },
    dataUrl: window.DATA_URL_BASE + `?deviceId=${options.vehicle.deviceId}`,
    infoWindow,
    setupOptions: options
  };
}

/**
 *
 * @param options {SetupResult}
 */
async function _refreshMapData(options) {
  console.log("fetching vehicle data");
  const vehicleDataFetchResult = await _fetchVehicleData(options);
  console.log("computing map data");
  const mapData = await _getMapData(options, vehicleDataFetchResult);
  console.log("updating UI");
  _updateUI(mapData, options);
}
/**
 *
 * @param options {SetupResult}
 */

async function _fetchVehicleData(options) {
  return (await axios({
    url: options.dataUrl,
    method: "GET",
    headers: {
      "content-type": "application/json",
      "x-api-key": window.DATA_APIKEY
    },
    crossDomain: true
  })).data;
}

/**
 *
 * @param options {SetupResult}
 * @param vehicleDataFetchResult {object}
 * @returns {Promise<MapData>}
 */
async function _getMapData(options, vehicleDataFetchResult) {
  const items = _.get(vehicleDataFetchResult, "vehicleData.Items");
  const lastGeofencingEvent = _.get(vehicleDataFetchResult, "lastGeofencingEvent.Items[0]");
  _.set(lastGeofencingEvent, "geoLocation", getGeoLocationByName(_.get(lastGeofencingEvent, "location")));

  let lastTimestamp = moment(items[0].timestamp);
  const lastLocation = lastTimestamp.isValid() && {
    timestamp: lastTimestamp,
    geoLocation: { latitude: items[0].latitude, longitude: items[0].longitude }
  };

  const navigation =
    lastLocation &&
    (await _fetchNavigation(lastLocation.geoLocation, options.mapData.ikeaLocation, options.mapData.stopLocation).catch(
      console.error
    ));

  const userMessage = _getUserMessage(lastGeofencingEvent, lastLocation, navigation, options);

  return { lastGeofencingEvent, lastLocation, navigation, userMessage };
}

/**
 *
 * @param [lastGeofencingEvent] {MapData.lastGeofencingEvent}
 * @param [lastLocation] {MapData.lastLocation}
 * @param navigation {NavigationResult}
 * @param setupResult {SetupResult}
 * @returns {UserMessage}
 * @private
 */
function _getUserMessage(lastGeofencingEvent, lastLocation, navigation, setupResult) {
  let message = null;
  let destination = null;
  let arrivalTime = null;

  console.log(lastGeofencingEvent.geoLocation);
  console.log(lastLocation);
  console.log(setupResult.mapData);

  (() => {
    if (!navigation || !lastGeofencingEvent || !lastGeofencingEvent.geoLocation) return;

    console.log(lastGeofencingEvent.type);

    if (lastGeofencingEvent.type === "enter") {
      message = `Shuttle bus is at ${
        lastGeofencingEvent.geoLocation.alias
      } and will leave shortly. (Check the schedule for departure time)`;
    } else if (lastGeofencingEvent.type === "leave") {
      switch (lastGeofencingEvent.geoLocation.label) {
        case setupResult.mapData.ikeaLocation.label:
          destination = setupResult.mapData.stopLocation.alias || destination;
          arrivalTime = navigation.timeToStop || arrivalTime;
          break;
        case setupResult.mapData.stopLocation.label:
          destination = setupResult.mapData.ikeaLocation.alias || destination;
          arrivalTime = navigation.timeToIkea || arrivalTime;
          break;
        default:
          console.warn(`unexpected label: ${lastGeofencingEvent.geoLocation.label}`);
      }
    }
  })();

  return { message, destination, arrivalTime };
}

/**
 * @typedef NavigationResult {object}
 * @property distanceToIkea {string}
 * @property timeToIkea {string}
 * @property distanceToStop {string}
 * @property timeToStop {string}
 */

/**
 *
 * @param origin {GeoLocation}
 * @param ikeaLocation {GeoLocation}
 * @param stopLocation {GeoLocation}
 * @returns {Promise<NavigationResult>}
 * @private
 */
function _fetchNavigation(origin, ikeaLocation, stopLocation) {
  return new Promise((resolve, reject) => {
    if (!origin) throw new Error("invalid origin");

    new google.maps.DistanceMatrixService().getDistanceMatrix(
      {
        origins: [new google.maps.LatLng(origin.latitude, origin.longitude)],
        destinations: [
          new google.maps.LatLng(ikeaLocation.latitude, ikeaLocation.longitude),
          new google.maps.LatLng(stopLocation.latitude, stopLocation.longitude)
        ],
        travelMode: "DRIVING"
      },
      (result, status) => {
        if (status !== "OK") reject(new Error(`failed to get distance matrix: ${status}`));
        resolve({
          distanceToIkea: _.get(result, "rows[0].elements[0].distance.text"),
          timeToIkea: _.get(result, "rows[0].elements[0].duration.text"),
          distanceToStop: _.get(result, "rows[0].elements[1].distance.text"),
          timeToStop: _.get(result, "rows[0].elements[1].duration.text")
        });
      }
    );
  });
}

/**
 *
 * @param mapData {MapData}
 * @param userMessage {UserMessage}
 * @param options {SetupResult}
 * @private
 */
function _updateUI(mapData, options) {
  const lastVehicleLocation = {
    lat: mapData.lastLocation.geoLocation.latitude,
    lng: mapData.lastLocation.geoLocation.longitude
  };
  // update map UI
  options.mapProps.map.setCenter(lastVehicleLocation);
  options.mapProps.map.setZoom(options.setupOptions.map.zoomLevel);
  options.mapProps.busMarker.setPosition(lastVehicleLocation);
  options.infoWindow.setContent(
    [
      `Shuttle bus located <b>${moment(mapData.lastLocation.timestamp).fromNow()}</b>`,
      moment(mapData.lastLocation.timestamp).format("dddd - hh:mm a")
    ].join(" - ")
  );
  options.infoWindow.open(options.mapProps.map, options.mapProps.busMarker);

  // update user message

  let messageDom = $("#bus-arrival-message");
  if (mapData.userMessage.message) messageDom.text(mapData.userMessage.message);
  else if (!mapData.userMessage.destination) messageDom.text("Shuttle bus arrival time is currently not available.");
  else
    messageDom.html(
      `Shuttle bus is currently on route to <b>${mapData.userMessage.destination}</b>. Approximate arrival time is <b>${
        mapData.userMessage.arrivalTime
      }</b>`
    );
}

/**
 *
 * @param name {string}
 * @returns {GeoLocation | undefined}
 */
function getGeoLocationByName(name) {
  if (!window.geolocations) throw new Error("must fetch geo locations first");

  const geoLocation = _.find(window.geolocations, { label: name });
  if (!geoLocation) console.error(`invalid location name: ${name}`);
  return geoLocation;
}

/**
 *
 * @param name {string}
 */
function getRoutesByName(name) {
  if (!window.busroutes) throw new Error("must fetch routes first");
  const result = _.find(window.busroutes, { label: name });
  if (!result) console.error(`invalid route name: ${name}`);
  return result;
}

async function prepareGeoLocations(url) {
  if (!window.geolocations) window.geolocations = (await axios.get(url, { crossDomain: true })).data.data;
}

async function prepareBusRoutes(url) {
  if (!window.busroutes) window.busroutes = (await axios.get(url, { crossDomain: true })).data.data;
}

async function prepare() {
  console.log("prepare bus routes data");
  await prepareBusRoutes(window.BUS_ROUTES_URL);
  console.log("prepare geo location data");
  await prepareGeoLocations(window.GEO_LOCATIONS_URL);
}

function loadSchedule(domId, url) {
  $(`#${domId}`).attr("src", url);
}

window.DATA_URL_BASE = "https://7550qi28b2.execute-api.us-east-1.amazonaws.com/production/getTrackingEvents";
window.DATA_APIKEY = "VPCIrxzy2rLzuy8SiFhU61v5zJvNQdo748j5dEUe";
window.BUS_IMAGE_URL = "https://s3.us-east-2.amazonaws.com/dashboard-campaign/busicon.png";
window.GEO_LOCATIONS_URL = "https://pitstop-ikea-bus-tracking.s3.amazonaws.com/geo.json";
window.BUS_ROUTES_URL = "https://pitstop-ikea-bus-tracking.s3.amazonaws.com/routes.json";
